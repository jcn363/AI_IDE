pub(crate) mod classify;
pub(crate) mod integers;

pub struct True;

pub struct False;

pub struct Less;

pub struct Equal;

pub struct Greater;
