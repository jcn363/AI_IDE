pub struct Struct;

#[typetag::serde]
impl Struct {}

fn main() {}
