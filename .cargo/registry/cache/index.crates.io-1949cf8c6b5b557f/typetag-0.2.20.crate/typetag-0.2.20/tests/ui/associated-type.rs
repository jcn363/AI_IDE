#[typetag::serde]
pub trait Trait {
    type Assoc;
}

fn main() {}
