#[typetag::serde]
pub trait Trait {
    const ASSOC: u8;
}

fn main() {}
