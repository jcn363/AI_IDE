use rstest::rstest;

#[rstest]
struct Foo;

#[rstest]
impl Foo {}

#[rstest]
mod mod_baz {}

