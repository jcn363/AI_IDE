# WebAssembly tower-lsp example

See [tower-lsp-web-demo](https://github.com/silvanshade/tower-lsp-web-demo) for a complete example that uses `tower-lsp` to build a language server which compiles to Wasm and runs in the browser.
