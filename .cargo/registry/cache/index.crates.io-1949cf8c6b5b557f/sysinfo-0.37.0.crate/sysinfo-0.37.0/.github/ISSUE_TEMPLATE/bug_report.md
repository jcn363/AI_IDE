---
name: Bug report
about: Create a report to help us improve
title: ''
labels: bug
assignees: ''

---

If you like my work, please consider sponsoring me!

**Describe the bug**
Please provide the system on which you're using `sysinfo` and also `sysinfo` version.

**To Reproduce**
Please provide the code showing the bug so it can be reproduced.
