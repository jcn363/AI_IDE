# typescript-definitions-derive

Exports serde-serializable structs and enums to Typescript definitions.

Please see documentation at [crates.io](https://crates.io/crates/typescript-definitions)

License: MIT/Apache-2.0
