Playground for testing high performance matrix multiplication.
