mod fastest;
pub use fastest::compress_fastest;
