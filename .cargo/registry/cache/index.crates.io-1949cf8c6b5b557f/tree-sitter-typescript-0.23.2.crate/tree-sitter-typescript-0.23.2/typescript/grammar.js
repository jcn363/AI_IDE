const defineGrammar = require('../common/define-grammar');

module.exports = defineGrammar('typescript');
